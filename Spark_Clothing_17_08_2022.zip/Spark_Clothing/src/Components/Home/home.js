import React from "react";
import ImageSlider from "../Carousel/ImageSlider";
import { SliderData } from "../Carousel/SliderData";


const Home = () => {
  return (
    <div>
    <ImageSlider slides={SliderData} />
    </div>
  );
};

export default Home;