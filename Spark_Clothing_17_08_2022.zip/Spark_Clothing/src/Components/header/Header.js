import React from "react";
import "./Header.scss";

function Header(props) {
  //props destructuring
  const { backgroundImage, title, desc } = props.headerData;
  return (
    <div className="carousel">
      <img className="img" src={backgroundImage} />
      <div className="center-text">
        <h1 className="title">{title}</h1>
        <h3 className="description">{desc}</h3>
      </div>
    </div>
  );
}

export default Header;
