import "./AboutUs.css";
import React, { useEffect, useState } from "react";





// class Aboutus extends React.Component {


//     // Constructor 
//     constructor(props) {
//         super(props);

//         this.state = {
//             items: [],
//             DataisLoaded: false
//         };
//     }

//     // ComponentDidMount is used to
//     // execute the code 
//     componentWillMount() {
//         fetch(
//             "http://localhost:5001/aboutData")
//             .then((res) => res.json())
//             .then((json) => {
//                 this.setState({
//                     items: json,
//                     DataisLoaded: true
//                 });
//             })
//     }


// render() {

const Aboutus = () => {
    const [data, setData] = useState("");

    useEffect(() => {
        fetch("http://localhost:5001/aboutData")
            .then((res) => res.json())
            .then((data) => setData(data));
    }, []);

    return (
        <div>

            <div className="container">
                <div className="row">

                    <div className="col-10">
                        <img className="img" src='assets\images\About Us.png' />
                        <div className="tagline" >{data.tagline}</div>
                        <div className="title">HISTORY</div>
                        <div className="history">{data.history}</div>

                    </div>
                </div>
            </div>
        </div>
    );

}

export default Aboutus;