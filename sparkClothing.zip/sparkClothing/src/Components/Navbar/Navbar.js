import React, { useState,useCallback, } from "react";
//import {useNavigate} from 'react-router-dom;
import "./Navbar.css";
import { NavLink, Routes, useNavigate } from "react-router-dom";
import Home from "../Home/home";
import { Route, Link, BrowserRouter as Router } from 'react-router-dom'
import Products from "../Products/products";
import Contact from "../Contact/contact";
import AboutUs from "../AboutUs/aboutus";
import ProductInfo from "../ProductInfo/ProductInfo";
// import About us from "../About us/aboutus";


const Navbar = () => {
  const [showMediaIcons, setShowMediaIcons] = useState(false);

  const navigate = useNavigate();
  const logoNavigate = useCallback(() => navigate('/home', {replace: true}), [navigate]);

  return (
    <div>
      <nav className="main-nav">
        {/* 1st logo part  */}
        <div className="logo" onClick={logoNavigate}>
          <img className="logo-img" src="assets\images\LOGO.jpg"/>
        </div>

        {/* 2nd menu part  */}
        <div
          className={
            showMediaIcons ? "menu-link mobile-menu-link" : "menu-link"
          }>
          <ul>
            <li>
              <Link to="/home">Home</Link>
            </li>
            <li>
              <Link to="/products">Products</Link>
            </li>
            <li>
              <Link to="/aboutus">AboutUs</Link>

            </li>
            <li>
              <Link to="/contact">ContactUs</Link>
            </li>
          </ul>
        </div>
      </nav>
      <div className="container">
      <Routes>
          <Route path="/home" element={<Home />} />
          <Route path="/products" element={<Products />} />
          <Route path="/aboutus" element={<AboutUs/>} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/productInfo/:id" element={<ProductInfo />} />

      </Routes>
      </div>
      </div>
  );
};

export default Navbar;