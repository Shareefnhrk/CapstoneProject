import React from 'react';
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react"
import './productInfo.css'
import "../Contact/contact.scss";

const ProductInfo = () => {
    const { id } = useParams();
    const [advice, setAdvice] = useState("");

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [number, setNumber] = useState("");
    const [message, setMessage] = useState("");

  let handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let res = await fetch(`http://localhost:5001/feedback`, {
        method: "POST",
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: name,
          email: email,
          number: number,
          message: message
        }),
      });
      let resJson = await res.json();
      if (res.status === 200) {
        setName("");
        setEmail("");
        setMessage("User created successfully");
      } else {
        setMessage("Some error occured");
      }
    } catch (err) {
      console.log(err);
    }
  };
    useEffect(() => {
        const url = "http://localhost:5001/data";

        const fetchData = async () => {
            try {
                const response = await fetch(url);
                const json = await response.json();
                const item = json.find((item) => item.id == id);
                console.log(item);
                setAdvice(item);
            } catch (error) {
                console.log("error", error);
            }
        };

        fetchData();
    }, []);
    return (
        <div>
            <img className='detail-img' src={`/assets/${advice.image}`} />
            <div>Name - {advice.name}</div>
            <div>brand - {advice.brand}</div>
            <div>price- {advice.price}</div>

            <div className="contact_form">
        <div className="container">
          <div className="row">
            <div className="col-5">
              <div className="contact_form_container py-5">
                <div className="contact_form_title">
                  Feedback</div>
                <form id="contact_form" onSubmit={handleSubmit}>
                  <div className="form-group">
                    <input type="text" value={name} id="contact_name" className="contact_name input_field form-control"
                      placeholder="Your name" onChange={(e) => setName(e.target.value)} required="true" />
                  </div>
                  <div className="form-group">
                    <input type="email" value={email} id="contact_email" className="contact_email input_field form-control"
                      placeholder="Your email" onChange={(e) => setEmail(e.target.value)} required="true" />
                  </div>
                  <div className="form-group">
                    <input type="number" value={number} id="contact_phone" className="contact_phone input_field form-control"
                      placeholder="Your Phone Number"  onChange={(e) => setNumber(e.target.value)} required="true" />
                  </div>
                  <div className="contact_text mt-3">
                    <textarea className="text_field form-control contact_form_message"
                      placeholder="Message" rows="3" onChange={(e) => setMessage(e.target.value)}></textarea>
                  </div>
                  <div className="contact_button">
                    <button type="submit" className="button contact_submit_button">Submit</button>
                  </div>

                </form>
              </div>
            </div>
            <div className="col-7">
              <img src="../assets/images/Feedback.png" />
            </div>
          </div>
        </div>
      </div>

        </div>

    );
}

export default ProductInfo;
